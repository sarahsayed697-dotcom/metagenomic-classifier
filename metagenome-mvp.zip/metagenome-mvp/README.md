# Metagenomic read classifier — MVP

Upload one FASTA file → k-mer (k=4) vectors → small 1-D CNN → table of viral / bacterial / host / unclassified.

## Structure
```
metagenome-mvp/
├─ backend/
│  ├─ app/  config.py kmer.py model.py classify.py main.py   # API + inference
│  │        training.py synthetic.py                         # training + placeholder data
│  ├─ train.py          # retrain (real data if present, else synthetic)
│  ├─ fetch_ncbi.py     # optional: download real reference sequences
│  ├─ make_sample.py    # regenerates sample/test_reads.fasta
│  ├─ data/reference/   # viral.fasta bacterial.fasta host.fasta (you add these)
│  └─ models/           # kmer_cnn.pt (created by training)
├─ frontend/            # Vite + React: upload + results table
└─ sample/test_reads.fasta
```

## Run
```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --port 8000      # first start trains a synthetic placeholder model (~seconds)

# frontend (second terminal)
cd frontend
npm install
npm run dev                           # open the printed URL (http://localhost:5173)
```
Then upload `sample/test_reads.fasta`.

## Synthetic vs real data
| Part | Status |
|---|---|
| Training set the model starts with | **Synthetic** (random Markov-chain "genomes", 60 per class). Accuracy on it says nothing about real biology. |
| `sample/test_reads.fasta` | **Synthetic**, from genomes not used in training. Pipeline test only. |
| FASTA parsing, k-mer vectors, GC%, CNN, thresholding, API, UI | Real code, independent of the data. |
| `fetch_ncbi.py` → `data/reference/*.fasta` | **Real NCBI sequences** (once you run it). Untested against live NCBI. |

## Switch to real data
```bash
cd backend
python fetch_ncbi.py --email you@example.com      # or drop your own viral/bacterial/host.fasta into data/reference/
python train.py                                   # uses them automatically; prints held-out accuracy + confusion matrix
# restart uvicorn
```
The UI warning disappears once the model is trained on real data. Validation splits by record, not by read.

## Behaviour to know
- Reads with a max class probability below 0.70 (`CONF_THRESHOLD` in `config.py`) are `unclassified`; hovering shows the closest class.
- Reads with fewer than 50 valid 4-mers (~53 bp) are `unclassified` with no confidence.
- Softmax confidence is uncalibrated, and the model is closed-set: DNA from anything else (plants, fungi, diet) may still get a confident wrong label.
- Limits: plain FASTA only, ≤25 MB, ≤20,000 records; the table shows the first 1,000 rows.

## Publish it (GitHub Pages + free backend host)
GitHub Pages serves static files only, so the site is split in two: the React frontend on GitHub Pages and the FastAPI/PyTorch backend in a container on Render (free tier; it sleeps when idle, so the first request after a pause can take about a minute).

1. **Push to GitHub.** Create an empty repo, then from this folder: `git init && git add . && git commit -m "MVP" && git branch -M main && git remote add origin https://github.com/<you>/<repo>.git && git push -u origin main`
2. **Deploy the backend.** On render.com choose New > Blueprint, pick the repo (it reads `render.yaml`) and set `ALLOWED_ORIGINS` to `https://<you>.github.io`. When it's live, copy its URL (e.g. `https://metagenome-api.onrender.com`) and check `<url>/health`.
3. **Point the frontend at it.** Repo Settings > Secrets and variables > Actions > Variables > New variable: `API_URL` = the Render URL.
4. **Turn on Pages.** Repo Settings > Pages > Source: **GitHub Actions**. Then run the "Deploy frontend to GitHub Pages" workflow (Actions tab) or push a change to `frontend/`. The site appears at `https://<you>.github.io/<repo>/`.

Other backend hosts work too (anything that runs the `backend/Dockerfile`; Hugging Face Spaces with a Docker Space is a good fit for ML). Set `ALLOWED_ORIGINS` on whichever you use.

Notes for a public site:
- Uploads are processed in memory and not stored, but anyone with the URL can send files, so keep the 25 MB / 20,000-record limits.
- The hosted model is retrained at build time: on synthetic data unless you commit `backend/data/reference/*.fasta` (then it trains on those, and the warning banner disappears).
- Add a LICENSE file of your choice before making the repo public.

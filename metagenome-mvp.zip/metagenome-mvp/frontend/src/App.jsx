import { useEffect, useState } from "react";

const API = (import.meta.env.VITE_API_URL || "http://localhost:8000").replace(/\/$/, "");
const MAX_ROWS = 1000;
const CLASSES = ["viral", "bacterial", "host", "unclassified"];

export default function App() {
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [data, setData] = useState(null);
  const [model, setModel] = useState(null);

  useEffect(() => {
    fetch(`${API}/health`)
      .then((r) => r.json())
      .then((j) => setModel(j.model))
      .catch(() => setError(`Can't reach the backend at ${API}. Locally, start it with: uvicorn app.main:app --port 8000. If this is the hosted site, the server may be waking up; try again in a minute.`));
  }, []);

  async function classify() {
    if (!file) return;
    setBusy(true);
    setError("");
    setData(null);
    try {
      const body = new FormData();
      body.append("file", file);
      const res = await fetch(`${API}/classify`, { method: "POST", body });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json.detail || `Request failed (${res.status})`);
      setData(json);
      setModel(json.model);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  const counts = data
    ? CLASSES.map((c) => [c, data.results.filter((r) => r.predicted_class === c).length])
    : [];

  return (
    <main>
      <h1>Read classifier</h1>
      <p className="lede">
        Upload a FASTA file of reads or contigs. Each one is labelled viral, bacterial or host (avian), or left
        unclassified when the model isn't confident.
      </p>

      {model?.trained_on === "synthetic" && (
        <p className="banner">
          This model was trained on synthetic placeholder sequences, so these labels aren't biologically meaningful
          yet. Retrain with real reference data (see the README).
        </p>
      )}

      <div className="upload">
        <input
          type="file"
          accept=".fa,.fasta,.fna,.fas,.txt"
          onChange={(e) => { setFile(e.target.files[0] ?? null); setData(null); setError(""); }}
        />
        <button onClick={classify} disabled={!file || busy}>
          {busy ? "Classifying…" : "Classify reads"}
        </button>
      </div>

      {error && <p className="error" role="alert">{error}</p>}

      {data && (
        <>
          <p className="summary">
            {data.n_reads.toLocaleString()} reads from {data.filename}:{" "}
            {counts.map(([c, n], i) => (
              <span key={c}>{i > 0 && ", "}{n.toLocaleString()} {c}</span>
            ))}
          </p>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Read ID</th>
                  <th className="num">Length (bp)</th>
                  <th className="num">GC %</th>
                  <th>Predicted class</th>
                  <th className="num">Confidence</th>
                </tr>
              </thead>
              <tbody>
                {data.results.slice(0, MAX_ROWS).map((r, i) => (
                  <tr key={i}>
                    <td className="id" title={r.id}>{r.id}</td>
                    <td className="num">{r.length.toLocaleString()}</td>
                    <td className="num">{r.gc.toFixed(1)}</td>
                    <td>
                      <span
                        className={`chip ${r.predicted_class}`}
                        title={r.predicted_class === "unclassified" && r.best_guess ? `Closest: ${r.best_guess}` : undefined}
                      >
                        {r.predicted_class}
                      </span>
                    </td>
                    <td className="num">{r.confidence == null ? "—" : `${(r.confidence * 100).toFixed(1)}%`}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {data.results.length > MAX_ROWS && (
            <p className="note">Showing the first {MAX_ROWS.toLocaleString()} of {data.results.length.toLocaleString()} reads.</p>
          )}
        </>
      )}
    </main>
  );
}

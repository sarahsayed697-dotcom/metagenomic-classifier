from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "kmer_cnn.pt"
REF_DIR = ROOT / "data" / "reference"   # viral.fasta, bacterial.fasta, host.fasta

CLASSES = ["viral", "bacterial", "host"]  # "unclassified" is decided by the threshold, not learned
K = 4                                     # fixed for the MVP
CONF_THRESHOLD = 0.70                     # max softmax prob below this -> "unclassified"
MIN_KMERS = 50                            # reads with fewer valid 4-mers -> "unclassified"

MAX_BYTES = 25 * 1024 * 1024
MAX_RECORDS = 20_000

import numpy as np
import torch

from . import config
from .kmer import kmer_vector, gc_percent
from .model import KmerCNN

_state = {}


def load_model():
    if "model" not in _state:
        if not config.MODEL_PATH.exists():
            print("No trained model found -- training a SYNTHETIC placeholder model (takes a few seconds)...")
            from .training import train
            train(force_synthetic=True)
        ckpt = torch.load(config.MODEL_PATH, map_location="cpu")
        model = KmerCNN(len(ckpt["classes"]))
        model.load_state_dict(ckpt["state_dict"])
        model.eval()
        _state["model"] = model
        _state["meta"] = {"trained_on": ckpt["trained_on"], "classes": ckpt["classes"],
                          "k": ckpt["k"], "threshold": config.CONF_THRESHOLD,
                          "val_accuracy": ckpt.get("val_accuracy")}
    return _state["model"], _state["meta"]


def classify_reads(records):
    """records: list of (id, sequence). Returns (rows, model_meta)."""
    model, meta = load_model()
    vecs, counts = zip(*(kmer_vector(seq) for _, seq in records))
    with torch.no_grad():
        probs = torch.softmax(model(torch.tensor(np.stack(vecs))), dim=1).numpy()

    rows = []
    for (rid, seq), p, n in zip(records, probs, counts):
        best = int(p.argmax())
        conf = float(p[best])
        if n < config.MIN_KMERS:
            label, conf_out = "unclassified", None       # too short to judge
        elif conf < config.CONF_THRESHOLD:
            label, conf_out = "unclassified", round(conf, 3)
        else:
            label, conf_out = meta["classes"][best], round(conf, 3)
        rows.append({"id": rid, "length": len(seq), "gc": gc_percent(seq),
                     "predicted_class": label, "confidence": conf_out,
                     "best_guess": meta["classes"][best] if n >= config.MIN_KMERS else None})
    return rows, meta

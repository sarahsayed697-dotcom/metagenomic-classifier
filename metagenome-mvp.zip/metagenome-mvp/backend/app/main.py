import io
import os
from contextlib import asynccontextmanager

from Bio import SeqIO
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from . import config
from .classify import classify_reads, load_model


@asynccontextmanager
async def lifespan(app):
    load_model()          # trains a synthetic placeholder model on first run if none exists
    yield


app = FastAPI(title="Metagenomic read classifier (MVP)", lifespan=lifespan)
# ALLOWED_ORIGINS: comma-separated, e.g. "https://yourname.github.io" (no path, no trailing slash)
ORIGINS = [o.strip().rstrip("/") for o in os.getenv("ALLOWED_ORIGINS", "").split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=ORIGINS, allow_origin_regex=r"http://(localhost|127\.0\.0\.1):\d+",
                   allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
def health():
    return {"status": "ok", "model": load_model()[1]}


@app.post("/classify")
def classify(file: UploadFile = File(...)):
    raw = file.file.read(config.MAX_BYTES + 1)
    if len(raw) > config.MAX_BYTES:
        raise HTTPException(413, f"File is larger than {config.MAX_BYTES // 1024 // 1024} MB.")
    if raw[:2] == b"\x1f\x8b":
        raise HTTPException(400, "Gzipped files are not supported yet. Upload an uncompressed FASTA file.")
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(400, "File is not plain text. Upload an uncompressed FASTA file.")
    if not text.lstrip().startswith(">"):
        raise HTTPException(400, "This does not look like FASTA (it should start with '>'). FASTQ is not supported yet.")

    records = [(r.id, str(r.seq)) for r in SeqIO.parse(io.StringIO(text), "fasta")]
    if not records:
        raise HTTPException(400, "No sequences found in the file.")
    if len(records) > config.MAX_RECORDS:
        raise HTTPException(400, f"Too many sequences ({len(records):,}). The MVP limit is {config.MAX_RECORDS:,}.")

    rows, meta = classify_reads(records)
    return {"filename": file.filename, "n_reads": len(rows), "model": meta, "results": rows}

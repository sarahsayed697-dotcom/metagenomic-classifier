"""SYNTHETIC sequence generator -- placeholder training data only.
Each class gets its own random order-3 Markov chain; every 'genome' is a noisy variant of it.
This lets the pipeline run end-to-end offline, but it has NO biological meaning."""
from functools import lru_cache
import numpy as np

ORDER = 3
CLASS_PARAMS = {"viral": (0.42, 101), "bacterial": (0.52, 202), "host": (0.41, 303)}  # (GC, seed)
_COMP = str.maketrans("ACGTacgtN", "TGCAtgcaN")


def revcomp(s: str) -> str:
    return s.translate(_COMP)[::-1]


@lru_cache(maxsize=None)
def _class_matrix(cls: str):
    gc, seed = CLASS_PARAMS[cls]
    rng = np.random.default_rng(seed)
    base = np.array([(1 - gc) / 2, gc / 2, gc / 2, (1 - gc) / 2])
    return rng.dirichlet(base * 40, size=4 ** ORDER)


def make_genome(cls: str, length: int, rng) -> str:
    P = np.vstack([rng.dirichlet(row * 150 + 1e-3) for row in _class_matrix(cls)])
    cum = P.cumsum(axis=1)
    u = rng.random(length)
    ctx, mask = int(rng.integers(0, 4 ** ORDER)), 4 ** ORDER - 1
    out = []
    for i in range(length):
        b = min(int(np.searchsorted(cum[ctx], u[i])), 3)
        out.append("ACGT"[b])
        ctx = ((ctx << 2) | b) & mask
    return "".join(out)


def fragment(seq: str, rng, n: int, lo: int = 100, hi: int = 400):
    """Cut n random 'reads' (random strand) out of a longer sequence."""
    reads = []
    for _ in range(n):
        L = min(int(rng.integers(lo, hi + 1)), len(seq))
        s = int(rng.integers(0, len(seq) - L + 1))
        r = seq[s:s + L]
        reads.append(revcomp(r) if rng.random() < 0.5 else r)
    return reads

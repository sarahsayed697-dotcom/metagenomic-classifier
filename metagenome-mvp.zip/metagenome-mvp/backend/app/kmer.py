import numpy as np
from .config import K

N_FEATURES = 4 ** K

_LUT = np.full(256, -1, dtype=np.int16)          # A,C,G,T -> 0..3 ; everything else -> -1
for _i, _b in enumerate("ACGT"):
    _LUT[ord(_b)] = _i
    _LUT[ord(_b.lower())] = _i


def kmer_vector(seq: str):
    """Return (frequency vector of length 4**K, number of valid k-mers).
    k-mers containing N or other non-ACGT characters are skipped."""
    codes = _LUT[np.frombuffer(seq.encode("ascii", "replace"), dtype=np.uint8)]
    n = len(codes) - K + 1
    if n <= 0:
        return np.zeros(N_FEATURES, dtype=np.float32), 0
    idx = np.zeros(n, dtype=np.int32)
    valid = np.ones(n, dtype=bool)
    for j in range(K):
        c = codes[j:j + n]
        valid &= c >= 0
        idx = idx * 4 + np.clip(c, 0, None)
    counts = np.bincount(idx[valid], minlength=N_FEATURES).astype(np.float32)
    total = int(counts.sum())
    if total:
        counts /= total
    return counts, total


def gc_percent(seq: str) -> float:
    s = seq.upper()
    acgt = sum(s.count(b) for b in "ACGT")
    return round(100 * (s.count("G") + s.count("C")) / acgt, 1) if acgt else 0.0

import numpy as np
import torch
import torch.nn as nn
from Bio import SeqIO

from . import config
from .kmer import kmer_vector
from .model import KmerCNN
from .synthetic import make_genome, fragment


def load_reference():
    """Real reference data: data/reference/{viral,bacterial,host}.fasta. None if any is missing."""
    paths = {c: config.REF_DIR / f"{c}.fasta" for c in config.CLASSES}
    if not all(p.exists() and p.stat().st_size > 0 for p in paths.values()):
        return None
    return {c: [str(r.seq).upper() for r in SeqIO.parse(p, "fasta")] for c, p in paths.items()}


def synthetic_reference(n_per_class=60, length=3000, seed=0):
    rng = np.random.default_rng(seed)
    return {c: [make_genome(c, length, rng) for _ in range(n_per_class)] for c in config.CLASSES}


def _split_by_record(ref, rng, val_frac=0.2):
    """Split whole records (not reads) so validation reads never come from a training record."""
    tr, va = {}, {}
    for c, recs in ref.items():
        recs = list(recs)
        rng.shuffle(recs)
        k = max(1, int(len(recs) * val_frac))
        va[c], tr[c] = recs[:k], recs[k:]
    return tr, va


def _vectorise(ref, rng, reads_per_record):
    X, y = [], []
    for ci, c in enumerate(config.CLASSES):
        for rec in ref[c]:
            if len(rec) < 100:
                continue
            for r in fragment(rec, rng, reads_per_record):
                v, n = kmer_vector(r)
                if n >= config.MIN_KMERS:
                    X.append(v)
                    y.append(ci)
    return torch.tensor(np.stack(X)), torch.tensor(y)


def train(force_synthetic=False, epochs=40, reads_per_record=25, seed=0, verbose=True):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    ref = None if force_synthetic else load_reference()
    trained_on = "ncbi" if ref else "synthetic"
    if ref is None:
        ref = synthetic_reference(seed=seed)
    if verbose:
        print(f"Training on {trained_on} data: " + ", ".join(f"{c}={len(ref[c])} records" for c in config.CLASSES))

    tr_ref, va_ref = _split_by_record(ref, rng)
    Xtr, ytr = _vectorise(tr_ref, rng, reads_per_record)
    Xva, yva = _vectorise(va_ref, rng, reads_per_record)

    model = KmerCNN(len(config.CLASSES))
    opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    loss_fn = nn.CrossEntropyLoss()
    for _ in range(epochs):
        model.train()
        perm = torch.randperm(len(Xtr))
        for i in range(0, len(perm), 64):
            b = perm[i:i + 64]
            opt.zero_grad()
            loss_fn(model(Xtr[b]), ytr[b]).backward()
            opt.step()

    model.eval()
    with torch.no_grad():
        probs = torch.softmax(model(Xva), 1)
    conf, pred = probs.max(1)
    acc = (pred == yva).float().mean().item()
    confident = conf >= config.CONF_THRESHOLD
    if verbose:
        print(f"Held-out accuracy (all reads): {acc:.3f}")
        if confident.any():
            print(f"Reads >= {config.CONF_THRESHOLD:.0%} confidence: {confident.float().mean():.1%}, "
                  f"accuracy among them: {(pred[confident] == yva[confident]).float().mean():.3f}")
        cm = np.zeros((3, 3), int)
        for t, p in zip(yva.tolist(), pred.tolist()):
            cm[t, p] += 1
        print("Confusion matrix (rows=true, cols=pred)", config.CLASSES)
        print(cm)

    config.MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "classes": config.CLASSES, "k": config.K,
                "trained_on": trained_on, "val_accuracy": round(acc, 3)}, config.MODEL_PATH)
    return config.MODEL_PATH

import torch.nn as nn
from .kmer import N_FEATURES


class KmerCNN(nn.Module):
    """Small 1-D CNN over the 256-long 4-mer frequency vector (lexicographic order)."""

    def __init__(self, n_classes: int = 3):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(1, 16, 5, padding=2), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(16, 32, 5, padding=2), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 32, 3, padding=1), nn.ReLU(), nn.AdaptiveAvgPool1d(8),
        )
        self.head = nn.Sequential(nn.Flatten(), nn.Dropout(0.3), nn.Linear(32 * 8, n_classes))

    def forward(self, x):                       # x: (batch, 256) frequencies summing to 1
        x = (x * N_FEATURES).unsqueeze(1)       # rescale so the mean feature is ~1
        return self.head(self.features(x))

"""Retrain the model.
   python train.py               # uses data/reference/*.fasta if all three exist, else synthetic data
   python train.py --synthetic   # force synthetic placeholder data"""
import argparse
from app.training import train

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--epochs", type=int, default=40)
    a = ap.parse_args()
    print("Saved", train(force_synthetic=a.synthetic, epochs=a.epochs))

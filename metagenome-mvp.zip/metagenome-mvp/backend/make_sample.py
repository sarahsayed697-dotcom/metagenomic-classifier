"""Writes ../sample/test_reads.fasta: SYNTHETIC reads from genomes the model never saw in training,
plus a few edge cases. The true label is in each header so you can eyeball the results."""
from pathlib import Path
import numpy as np
from app.synthetic import make_genome, fragment

rng = np.random.default_rng(12345)          # different from the training seed (0)
out = []
for cls in ("viral", "bacterial", "host"):
    genome = make_genome(cls, 4000, rng)
    for i, r in enumerate(fragment(genome, rng, 12)):
        out.append((f"{cls}_{i+1:02d} true={cls} synthetic", r))
out += [("edge_too_short true=none", "ACGTACGTAC"),
        ("edge_with_Ns true=none", "ACGT" * 10 + "N" * 30 + "GGCATTAGC" * 8),
        ("edge_poly_A true=none", "A" * 200)]
p = Path(__file__).resolve().parents[1] / "sample" / "test_reads.fasta"
p.write_text("".join(f">{h}\n{s}\n" for h, s in out))
print("wrote", p, len(out), "reads")

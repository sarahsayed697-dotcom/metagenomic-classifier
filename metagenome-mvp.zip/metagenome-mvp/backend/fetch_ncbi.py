"""OPTIONAL: download a small real reference set from NCBI into data/reference/{viral,bacterial,host}.fasta
   python fetch_ncbi.py --email you@example.com [--per-class 60] [--window 20000]

Each record is capped at --window bp (a random window for large genomes/chromosomes) to keep the download small.
Queries below are starting points -- edit them to match the taxa you care about (wild-bird pathogens, etc.).
UNTESTED against live NCBI from the build environment; check the output FASTA files before training."""
import argparse, math, random, time
from pathlib import Path
from Bio import Entrez

REFSEQ = "srcdb_refseq[PROP] AND biomol_genomic[PROP]"
QUERIES = {
    "viral": [
        f'"Influenza A virus"[Organism] AND {REFSEQ}',
        f'"Avian orthoavulavirus 1"[Organism] AND {REFSEQ}',          # Newcastle disease virus
        f'"Infectious bronchitis virus"[Organism] AND {REFSEQ}',
        f'"Aviadenovirus"[Organism] AND {REFSEQ}',
    ],
    "bacterial": [
        f'"Escherichia coli"[Organism] AND {REFSEQ} AND 1000000:7000000[SLEN]',
        f'"Salmonella enterica"[Organism] AND {REFSEQ} AND 1000000:7000000[SLEN]',
        f'"Campylobacter jejuni"[Organism] AND {REFSEQ} AND 1000000:7000000[SLEN]',
        f'"Clostridium perfringens"[Organism] AND {REFSEQ} AND 1000000:7000000[SLEN]',
    ],
    "host": [   # avian chromosomes (large) -- windows are sampled from them
        f'"Gallus gallus"[Organism] AND {REFSEQ} AND 5000000:400000000[SLEN]',
        f'"Anas platyrhynchos"[Organism] AND {REFSEQ} AND 5000000:400000000[SLEN]',
        f'"Columba livia"[Organism] AND {REFSEQ} AND 5000000:400000000[SLEN]',
        f'"Taeniopygia guttata"[Organism] AND {REFSEQ} AND 5000000:400000000[SLEN]',
    ],
}


def fetch_class(cls, queries, per_class, window, rng):
    per_query = math.ceil(per_class / len(queries))
    records, seen = [], set()
    for q in queries:
        ids = Entrez.read(Entrez.esearch(db="nuccore", term=q, retmax=per_query * 3))["IdList"]
        ids = [i for i in ids if i not in seen][:per_query]
        if not ids:
            print(f"  [warn] no hits for: {q}")
            continue
        summaries = Entrez.read(Entrez.esummary(db="nuccore", id=",".join(ids)))
        for s in summaries:
            length, uid = int(s["Length"]), str(s["Id"])
            seen.add(uid)
            start = rng.randint(1, max(1, length - window + 1)) if length > window else 1
            stop = min(length, start + window - 1)
            h = Entrez.efetch(db="nuccore", id=uid, rettype="fasta", retmode="text", seq_start=start, seq_stop=stop)
            records.append(h.read().strip())
            time.sleep(0.4)                       # stay under NCBI's rate limit
    return records[:per_class]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--email", required=True, help="NCBI asks for a contact email")
    ap.add_argument("--api-key", default=None)
    ap.add_argument("--per-class", type=int, default=60)
    ap.add_argument("--window", type=int, default=20000)
    a = ap.parse_args()
    Entrez.email, Entrez.api_key = a.email, a.api_key
    out_dir = Path(__file__).parent / "data" / "reference"
    out_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(0)
    for cls, qs in QUERIES.items():
        print(f"Fetching {cls} ...")
        recs = fetch_class(cls, qs, a.per_class, a.window, rng)
        (out_dir / f"{cls}.fasta").write_text("\n".join(recs) + "\n")
        print(f"  saved {len(recs)} records -> data/reference/{cls}.fasta")
